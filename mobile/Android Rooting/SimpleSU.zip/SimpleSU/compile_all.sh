echo "/////////Build Start//////////"

cd mydaemon
sh compile.sh
cd ..

cd mysu
sh compile.sh
cd ..

echo "/////////Build End////////////"